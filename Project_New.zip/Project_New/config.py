IMEI = "Dán ImeI Của Bạn Vào Đây"
SESSION_COOKIES = {"Dán Cookie Của Bạn Ở Ngoài Ngoặc"}
API_KEY = 'api_key'
SECRET_KEY = 'secret_key'
PREFIX = '/'
ADMIN = 'Dán Uid Của Bạn Vào Đây'
