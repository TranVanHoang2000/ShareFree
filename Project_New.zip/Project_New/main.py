from config import API_KEY, SECRET_KEY, IMEI, SESSION_COOKIES, PREFIX
from tvh_zlbot import CommandHandler
from zlapi import ZaloAPI
from zlapi.models import Message
from modules.bot import *
from modules.welcome.welcome import welcome
from colorama import Fore, Style, init
import time
import os
import pyfiglet

init(autoreset=True)

chuto = "TVH"
hien = pyfiglet.figlet_format(chuto)

os.system('cls' if os.name == 'nt' else 'clear')
print(hien)

class Client(ZaloAPI):
    def __init__(self, api_key, secret_key, imei, session_cookies):
        super().__init__(api_key, secret_key, imei=imei, session_cookies=session_cookies)
        handle_bot_admin(self)
        self.version = 1.0
        self.me_name = "Trần Văn Hoàng"
        self.date_update = "21/6/2025"
        self.command_handler = CommandHandler(self)

    def onEvent(self, event_data, event_type):
        welcome(self, event_data, event_type)

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        print(f"{Fore.WHITE}{Style.BRIGHT}-----------------------------------------------------------------------\n"
              f"<> Nội Dung Tin Nhắn <>\n"
              f"- Tin Nhắn : {Fore.GREEN}{Style.BRIGHT}{message}{Style.NORMAL}\n"
              f"- Id Người Dùng : {Fore.RED}{Style.BRIGHT}{author_id} {Style.NORMAL}\n"
              f"- Id Nhóm : {Fore.CYAN}{Style.BRIGHT}{thread_id}{Style.NORMAL}\n"
              f"- Type : {Fore.YELLOW}{Style.BRIGHT}{thread_type}{Style.NORMAL}\n"
              f"- Tin Nhắn Nội Dung : {Fore.BLUE}{Style.BRIGHT}{message_object}{Style.NORMAL}\n"
              f"{Fore.WHITE}{Style.BRIGHT}-----------------------------------------------------------------------\n"
              )
        allowed_thread_ids = get_allowed_thread_ids()
        if thread_id in allowed_thread_ids and thread_type == ThreadType.GROUP and not is_admin(author_id):
            handle_check_profanity(self, author_id, thread_id, message_object, thread_type, message)
        try:
            if isinstance(message, str):
                if message == f"{PREFIX}":
                    self.send(Message(text=f"➜ Dùng {PREFIX}Menu Hoặc {PREFIX}Bot Để Biết Rõ Hơn !"), thread_id, thread_type)
                    return
                self.command_handler.handle_command(message, author_id, message_object, thread_id, thread_type)
        except:
            pass

def run_bot():
    while True:
        try:
            client = Client(API_KEY, SECRET_KEY, IMEI, SESSION_COOKIES)
            client.listen(thread=True, delay=0)
        except Exception as e:
            print(f"Bot Bị Ngắt Kết Nối : {e}")
            time.sleep(5)

if __name__ == "__main__":
    run_bot()