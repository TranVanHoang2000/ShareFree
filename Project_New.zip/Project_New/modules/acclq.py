import random
import time
from zlapi.models import Message

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Lấy Acc Liên Quân Miễn Phí"
}

def read_accounts_from_file(file_path):
    try:
        with open(file_path, 'r') as file:
            accounts = file.readlines()
        return [account.strip() for account in accounts]
    except Exception as e:
        print(f"➜ Lỗi Khi Đọc File : {str(e)}")
        return []

def handle_acclq_command(message, message_object, thread_id, thread_type, author_id, client):
    try:
        try:
            num_accounts = int(message.split()[1])
        except (IndexError, ValueError):
            client.replyMessage(Message(text="Vui lòng Nhập Số Tài Khoản Liên Quân Muón Lấy Sau Lệnh /LayAccLq\nVí Dụ : /LayAccLq 10"), message_object, thread_id, thread_type,ttl=20000)
            return

        accounts = read_accounts_from_file('file/file_txt/acclq.txt')
        if not accounts:
            client.replyMessage(Message(text="➜ Không Thể Đọc Danh Sách Tài Khoản Liên Quân."), message_object, thread_id, thread_type,ttl=10000)
            return

        if num_accounts > len(accounts):
            client.replyMessage(Message(text=f"➜ Chỉ Có {len(accounts)} Tài Khoản Liên Quân !"), message_object, thread_id, thread_type,ttl=120000)
            return

        selected_accounts = random.sample(accounts, num_accounts)       
        
        message_to_send = f"➜ Đã Gửi {num_accounts} Tài Khoản Liên Quân Mà Id '{author_id}' Yêu Cầu :\n" + "\n".join(selected_accounts)

        client.replyMessage(Message(text=message_to_send), message_object, thread_id, thread_type)
        print(f"➜ Đã Gửi {num_accounts} Tài Khoản Cho Id {author_id}")

    except Exception as e:
        error_message = f"➜ Lỗi Khi Gửi Tài Khoản Liên Quân : {str(e)}"
        client.replyMessage(Message(text=error_message), message_object, thread_id, thread_type,ttl=120000)

def get_tvh_zlbot():
    return {
        'acclq': handle_acclq_command
    }