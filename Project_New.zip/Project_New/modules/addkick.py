from zlapi.models import Message
from config import ADMIN
import time

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Thêm Xóa Thành Viên Trong Nhóm Liên Tục"
}

def is_admin(author_id):
    return author_id in ADMIN

def handle_themtv_command(user_id, thread_id, thread_type, author_id, client):
    try:
        if hasattr(client, 'addUsersToGroup'):
            response = client.addUsersToGroup([user_id], thread_id)
            send_message = f"➜ Đã Thêm Người Dùng Có ID '{user_id}' Vào Nhóm Thành Công !"
        else:
            send_message = "➜ Đã Xảy Ra Lỗi Gì Đó !"
    except Exception as e:
        send_message = f"➜ Lỗi Khi Thêm Người Dùng Vào Nhóm : {str(e)}"

    gui = Message(text=send_message)
    client.sendMessage(gui, thread_id, thread_type)

def handle_xoatv_command(user_id, thread_id, thread_type, author_id, client):
    try:
        if hasattr(client, 'kickUsersInGroup'):
            response = client.kickUsersInGroup(user_id, thread_id)
            send_message = f"➜ Đã Xóa Người Dùng Có ID '{user_id}' Khỏi Nhóm Thành Công !"
        else:
            send_message = "➜ Đã Xảy Ra Lỗi Gì Đó !"
    except Exception as e:
        send_message = f"➜ Lỗi Khi Xóa Người Dùng Khỏi Nhóm Thành Công : {str(e)}"

    gui = Message(text=send_message)
    client.sendMessage(gui, thread_id, thread_type)

def handle_addkick_command(message, message_object, thread_id, thread_type, author_id, client):
    if not is_admin(author_id):
        error_message = Message(text="➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot !")
        client.sendMessage(error_message, thread_id, thread_type)
        return

    text = message.split()

    if len(text) < 3 or not text[2].isdigit():
        error_message = Message(text="➜ Vui Lòng Nhập [Id] [Số Lần] Sau Lệnh ThemXoa - Vd : ThemXoa 552955919389827360 10")
        client.sendMessage(error_message, thread_id, thread_type)
        return

    user_id = text[1]
    count = int(text[2])

    for i in range(count):
        handle_themtv_command(user_id, thread_id, thread_type, author_id, client)
        time.sleep(0.5)
        
        handle_xoatv_command(user_id, thread_id, thread_type, author_id, client)
        time.sleep(0.5)

def get_tvh_zlbot():
    return {
        'addkick': handle_addkick_command
    }