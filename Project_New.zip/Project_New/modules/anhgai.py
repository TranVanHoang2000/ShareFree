from zlapi.models import Message
import requests
import random
import os

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Xem Ảnh Gái"
}

a = ["1", "2", "3", "4", "6", "9", "12"]

def handle_anhgai_command(message, message_object, thread_id, thread_type, author_id, client):
    try:
        image_list_url = "https://github.com/TranVanHoang2000/Json/raw/refs/heads/main/AnhVideoGai.json"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'
        }

        response = requests.get(image_list_url, headers=headers)
        response.raise_for_status()
        json_data = response.json()
        rd = random.choice(a)

        if isinstance(json_data, dict) and 'url' in json_data:
            image_urls = [json_data['url']]
        elif isinstance(json_data, list):
            image_urls = random.sample(json_data, min(int(rd), len(json_data)))
        else:
            raise ValueError("➜ Dữ Liệu Trả Về Không Hợp Lệ !")

        image_paths = []
        for index, image_url in enumerate(image_urls):
            image_response = requests.get(image_url, headers=headers)
            image_path = f'modules/cache/temp_image{index + 1}.jpeg'
            with open(image_path, 'wb') as f:
                f.write(image_response.content)
            image_paths.append(image_path)

        if all(os.path.exists(path) for path in image_paths):
            total_images = len(image_paths)
            t = Message(text=f"Đã Gửi : {total_images} Ảnh")

            client.sendMultiLocalImage(
                imagePathList=image_paths,
                message=t,
                thread_id=thread_id,
                thread_type=thread_type,
                width=1200,
                height=1600
            )

            for path in image_paths:
                os.remove(path)
        else:
            raise FileNotFoundError("➜ Không Thể Lưu Ảnh !")

    except requests.exceptions.RequestException as e:
        error_message = Message(text=f"➜ Đã Xảy Ra Lỗi Khi Gọi API : {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type)
    except Exception as e:
        error_message = Message(text=f"➜ Đã Xảy Ra Lỗi : {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type)

def get_tvh_zlbot():
    return {
        'anhgai': handle_anhgai_command
    }
