import json
import re
from zlapi import ZaloAPI
from threading import Thread
from config import PREFIX
from zlapi.models import *
import time

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Quản Lý Nhóm"
}

SETTING_FILE = 'setting.json'
CONFIG_FILE = 'config.json'

def load_message_log():
    try:
        with open(SETTING_FILE, 'r', encoding='utf/8') as f:
            settings = json.load(f)
            return settings.get("message_log", {})
    except FileNotFoundError:
        return {}

def save_message_log(message_log):
    try:
        with open(SETTING_FILE, 'r', encoding='utf/8') as f:
            settings = json.load(f)
    except FileNotFoundError:
        settings = {}

    settings["message_log"] = message_log
    
    with open(SETTING_FILE, 'w', encoding='utf/8') as f:
        json.dump(settings, f, ensure_ascii=False, indent=4)

def get_content_message(message_object):
    if message_object.msgType == 'chat.sticker':
        return ""
    
    content = message_object.content
    
    if isinstance(content, dict) and 'title' in content:        
        text_to_check = content['title']
    else:     
        text_to_check = content if isinstance(content, str) else ""
    return text_to_check

def is_url_in_message(message_object):
    if message_object.msgType == 'chat.sticker':
        return False
    
    content = message_object.content
     
    if isinstance(content, dict) and 'title' in content:
        text_to_check = content['title']
    else:
        text_to_check = content if isinstance(content, str) else ""
    
    url_regex = re.compile(
        r'http[s]?://' 
        r'(?:[a/zA/Z]|[0/9]|[$/_@.&+]|[!*\\(\\),]|' 
        r'(?:%[0/9a/fA/F][0/9a/fA/F]))+'  
    )
   
    if re.search(url_regex, text_to_check):
        return True   
    return False
    
    message_log = load_message_log()
    
    key = f"{thread_id}_{author_id}"
    current_time = time.time()
    
    if key in message_log:
        user_data = message_log[key]
        last_message_time = user_data['last_message_time']
        message_times = user_data['message_times']
            
        if current_time / last_message_time < min_interval:       
            recent_messages = [t for t in message_times if current_time / t <= min_interval]
            if len(recent_messages) >= 10:
                return True  
         
        message_times = [t for t in message_times if current_time / t <= time_window]     
 
        message_times.append(current_time)
        
        message_log[key] = {
            'last_message_time': current_time,
            'message_times': message_times
        }
              
        if len(message_times) > max_messages:
            return True    
    else:
        message_log[key] = {
            'last_message_time': current_time,
            'message_times': [current_time]
        }
    
    save_message_log(message_log)  
    return False 


def read_settings():
    try:
        with open(SETTING_FILE, 'r', encoding='utf/8') as file:
            return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def write_settings(settings):
    with open(SETTING_FILE, 'w', encoding='utf/8') as file:
        json.dump(settings, file, ensure_ascii=False, indent=4)

def load_config():
    try:
        with open(CONFIG_FILE, 'r') as file:
            config = json.load(file)
            imei = config.get('imei')
            session_cookies = config.get('cookies')
            return imei, session_cookies
    except FileNotFoundError:
        print(f"➜ Lỗi : File {CONFIG_FILE} Không Tồn Tại !")
        return None, None
    except json.JSONDecodeError:
        print(f"➜Lỗi : File {CONFIG_FILE} Chứa JSON Không Hợp Lệ !")
        return None, None

def is_admin(author_id):
    settings = read_settings()
    admin_bot = settings.get("admin_bot", [])
    if author_id in admin_bot:
        return True
    else:
        return False

def handle_bot_admin(bot):
    settings = read_settings()
    admin_bot = settings.get("admin_bot", [])
    if bot.uid not in admin_bot:
        admin_bot.append(bot.uid)
        settings['admin_bot'] = admin_bot
        write_settings(settings)
        print(f"\x1b[48;2;249;226;175m ADDER \x1b[0m Đã Thêm : {get_user_name_by_id(bot, bot.uid)} ID : {bot.uid} Cho Lần Đầu Tiên Khởi Động Vào Danh Sách Admin Của Bot !")

def get_allowed_thread_ids():
    settings = read_settings()
    return settings.get('allowed_thread_ids', [])

def bot_on_group(bot, thread_id):
    try:
        settings = read_settings()
        allowed_thread_ids = settings.get('allowed_thread_ids', [])
        group = bot.fetchGroupInfo(thread_id).gridInfoMap[thread_id]

        if thread_id not in allowed_thread_ids:
            allowed_thread_ids.append(thread_id)
            settings['allowed_thread_ids'] = allowed_thread_ids
            write_settings(settings)

            return f"[Bot 𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜] Đã Được Bật Trong Nhóm : {group.name} - ID : {thread_id}\n➜ Gõ Lệnh {PREFIX}Bot Hoặc {PREFIX}Menu Để Xem Danh Sách Tính Năng Của Bot !"
    except Exception as e:
        print(f"➜ Lỗi  : {e}")
        return "➜ Đã Xảy Ra Lỗi Gì Đó !"

def bot_off_group(bot, thread_id):
    try:
        settings = read_settings()
        allowed_thread_ids = settings.get('allowed_thread_ids', [])
        group = bot.fetchGroupInfo(thread_id).gridInfoMap[thread_id]

        if thread_id in allowed_thread_ids:
            allowed_thread_ids.remove(thread_id)
            settings['allowed_thread_ids'] = allowed_thread_ids
            write_settings(settings)

            return f"[Bot 𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜] Đã Được Tắt Trong Nhóm : {group.name} - ID : {thread_id}\n➜ Chào Tạm Biệt, Chúc Bạn May Mắn"
    except Exception as e:
        print(f"➜ Lỗi : {e}")
        return "➜ Đã Xảy Ra Lỗi Gì Đó️ !"

def add_forbidden_word(word):
    settings = read_settings()
    forbidden_words = settings.get('forbidden_words', [])
    
    if word not in forbidden_words:
        forbidden_words.append(word)
        settings['forbidden_words'] = forbidden_words
        write_settings(settings)
        return f"➜ Từ '{word}' Đã Được Thêm Vào Danh Sách Từ Cấm !"
    else:
        return f"➜ Từ '{word}' Đã Tồn Tại Trong Danh Sách Từ Cấm !"

def remove_forbidden_word(word):
    settings = read_settings()
    forbidden_words = settings.get('forbidden_words', [])
    
    if word in forbidden_words:
        forbidden_words.remove(word)
        settings['forbidden_words'] = forbidden_words
        write_settings(settings)
        return f"➜ Từ '{word}' Đã Được Xóa Khỏi Danh Sách Từ Cấm !"
    else:
        return f"➜ Từ '{word}' Không Có Trong Danh Sách Từ Cấm !"

def is_forbidden_word(word):
    settings = read_settings()
    forbidden_words = settings.get('forbidden_words', [])
    return word in forbidden_words

def setup_bot_on(bot, thread_id):
   
    group = bot.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
  
    admin_ids = group.adminIds.copy()
    if group.creatorId not in admin_ids:
        admin_ids.append(group.creatorId)
    
    if bot.uid in admin_ids:      
        settings = read_settings()
              
        if 'group_admins' not in settings:
            settings['group_admins'] = {}  
      
        settings['group_admins'][thread_id] = admin_ids      
        write_settings(settings)      
        return f"[Bot 𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜 ]\n➜ Cấu Hình Thành Công Nội Quy Nhóm : {group.name} - ID : {thread_id}\n➜ Hãy Nhắn Tin Một Cách Văn Minh, Lịch Sự !\n➜ Chúc Bạn May Mắn !"
    else:
        return f"[Bot 𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜]\n➜ Cấu Hình Thất Bại Cho Nhóm : {group.name} - ID : {thread_id}\n➜ Bot 𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜 Không Có Key Quản Trị Nhóm Này !"

def setup_bot_off(bot,thread_id):
    group = bot.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
    settings = read_settings()

    if 'group_admins' in settings:  
        if thread_id in settings['group_admins']:
            del settings['group_admins'][thread_id]    
            write_settings(settings)            
            return f"[Bot 𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜]\n➜ Đã Hủy Bỏ Thành Công Cấu Hình Quản Trị Cho Nhóm : {group.name} - ID : {thread_id}\n➜ Tạm Biệt, Chúc Bạn May Mắn !"
        else:
            return f"[Bot 𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜]\n➜ Không Tìm Thấy Cấu Hình Quản Trị Cho Nhóm : {group.name} - ID : {thread_id} Để Hủy Bỏ !"
    else:
        return f"[Bot 𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜]\n➜ Không Có Thông Tin Quản Trị Nào Trong Cài Đặt Để Hủy Bỏ !"

def check_admin_group(bot,thread_id):
    group = bot.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
    admin_ids = group.adminIds.copy()
    if group.creatorId not in admin_ids:
        admin_ids.append(group.creatorId)
    settings = read_settings()
    if 'group_admins' not in settings:
        settings['group_admins'] = {}
    settings['group_admins'][thread_id] = admin_ids
    write_settings(settings)

    if bot.uid in admin_ids:
        return True
    else:
        return False

def get_allow_link_status(thread_id):
    settings = read_settings()

    if 'allow_link' in settings:      
        return settings['allow_link'].get(thread_id, False)
    else:     
        return False

def check_spam(bot, author_id, thread_id, message_object, thread_type):
    settings = read_settings()
    spam_enabled = settings.get('spam_enabled', False)
    
    if isinstance(spam_enabled, bool):
        if spam_enabled:
            settings['spam_enabled'] = {thread_id: True}
        else:
            settings['spam_enabled'] = {}
        write_settings(settings)
    spam_enabled = settings['spam_enabled']

    if not spam_enabled.get(thread_id, False):
        return

def handle_check_profanity(bot, author_id, thread_id, message_object, thread_type, message):
    def send_check_profanity_response():
        settings = read_settings()
        admin_ids = settings.get('group_admins', {}).get(thread_id, [])
        if bot.uid not in admin_ids:
            return
        spam_thread = threading.Thread(target=check_spam, args=(bot, author_id, thread_id, message_object, thread_type))
        spam_thread.start()
 
        if get_allow_link_status(thread_id) and is_url_in_message(message_object):
            bot.deleteGroupMsg(message_object.msgId, author_id, message_object.cliMsgId, thread_id)
            return
            
        muted_users = settings.get('muted_users', [])
        for muted_user in muted_users:
            if muted_user['author_id'] == author_id and muted_user['thread_id'] == thread_id:
                bot.deleteGroupMsg(message_object.msgId, author_id, message_object.cliMsgId, thread_id)
        if not isinstance(message, str):
            return
        message_text = str(message)
        forbidden_words = settings.get('forbidden_words', [])
        violations = settings.get('violations', {})
        rules = settings.get("rules", {})
        current_time = int(time.time())
        word_rule = rules.get("word", {"threshold": 3, "duration": 30})
        threshold_word = word_rule["threshold"]
        duration_word = word_rule["duration"]

        for muted_user in muted_users:
            if muted_user['author_id'] == author_id and muted_user['thread_id'] == thread_id:
                if current_time >= muted_user['muted_until']:
                    muted_users.remove(muted_user)
                    settings['muted_users'] = muted_users

                    if author_id in violations and thread_id in violations[author_id]:
                        violations[author_id][thread_id]['profanity_count'] = 0

                    write_settings(settings)
                    response = f"➜ Bạn Đã Được Phép Nhắn Tin ! Hãy Nhắn Tin Thật Lịch Sự Nhé !"
                    bot.replyMessage(Message(text=response), message_object, thread_id=thread_id, thread_type=thread_type)
                bot.deleteGroupMsg(message_object.msgId, author_id, message_object.cliMsgId, thread_id)
                return

        if any(word.lower() in message_text.lower() for word in forbidden_words):
            user_violations = violations.setdefault(author_id, {}).setdefault(thread_id, {'profanity_count': 0, 'spam_count': 0, 'penalty_level': 0})
            user_violations['profanity_count'] += 1
            profanity_count = user_violations['profanity_count']
            penalty_level = user_violations['penalty_level']

            if penalty_level >= 2:
                response = f"➜ Thành Viên {user} Đã Bị Xóa Khỏi Nhóm Do Vi Phạm Nhiều Lần !\n➜ Nội Dung Vi Phạm : Sử Dụng Từ Ngữ Thô Tục : '{message_text}'"
                bot.replyMessage(Message(text=response), message_object, thread_id=thread_id, thread_type=thread_type)
                bot.kickUsersInGroup( author_id, thread_id)
                bot.blockUsersInGroup( author_id, thread_id)
                        
                muted_users = [user for user in muted_users if not (user['author_id'] == author_id and user['thread_id'] == thread_id)]
                settings['muted_users'] = muted_users

                if author_id in violations:
                    violations[author_id].pop(thread_id, None)
                    if not violations[author_id]: 
                        violations.pop(author_id, None)
                write_settings(settings)
                return

            if profanity_count >= threshold_word:
                penalty_level += 1
                user_violations['penalty_level'] = penalty_level 

                muted_users.append({
                    'author_id': author_id,
                    'thread_id': thread_id,
                    'reason': f'{message_text}',
                    'muted_until': current_time + 60 * duration_word
                })
                settings['muted_users'] = muted_users
                write_settings(settings)

                response = f"➜ Bạn Đã Vi Phạm {threshold_word} Lần\n➜ Bạn Đã Bị Cấm Nhắn Tin Trong {duration_word} Phút\n➜ Nội Dung Vi Phạm : Sử Dụng Từ Ngữ Thô Tục : '{message_text}'"
                bot.replyMessage(Message(text=response), message_object, thread_id=thread_id, thread_type=thread_type)
                return
            elif profanity_count == threshold_word / 1:
                response = f"➜ Cảnh Báo : Bạn Đã Vi Phạm {profanity_count}/{threshold_word} Lần\n➜ Nếu Bạn Tiếp Tục Vi Phạm, Bạn Sẽ Bị Cấm Nhắn Tin Trong {duration_word} Phút\n➜ Nội Dung Vi Phạm : Sử Dụng Từ Ngữ Thô Tục : '{message_text}'"
                bot.replyMessage(Message(text=response), message_object, thread_id=thread_id, thread_type=thread_type)
            else:              
                response = f"➜ Bạn Đã Vi Phạm {profanity_count}/{threshold_word} Lần !\n➜ Nội Dung Vi Phạm : Sử Dụng Từ Ngữ Thô Tục : '{message_text}'"
                bot.replyMessage(Message(text=response), message_object, thread_id=thread_id, thread_type=thread_type)
            write_settings(settings)  

    thread = Thread(target=send_check_profanity_response)
    thread.start()

def get_user_name_by_id(bot,author_id):
    try:
        user = bot.fetchUserInfo(author_id).changed_profiles[author_id].displayName
        return user
    except:
        return "Người Dùng Không Xác Định"

def print_muted_users_in_group(bot, thread_id):
    settings = read_settings()
    muted_users = settings.get("muted_users", [])
    current_time = int(time.time())
    muted_users_list = []

    for user in muted_users:
        if user['thread_id'] == thread_id:
            author_id = user['author_id']
            user_name = get_user_name_by_id(bot, author_id)
            muted_until = user['muted_until']
            remaining_time = muted_until / current_time
            reason = user['reason']

            if remaining_time > 0:
                minutes_left = remaining_time // 60
                muted_users_list.append({
                    "author_id": author_id,
                    "name": user_name,
                    "minutes_left": minutes_left,
                    "reason": reason
                })

    muted_users_list.sort(key=lambda x: x['minutes_left'])

    if muted_users_list:
        result = "➜ Danh Sách Các Thành Viên Bị Cấm Nhắn Tin :\n"
        result += "\n".join(f"{i}. Tên : {user['name']} / Thời Gian Phạt : {user['minutes_left']} Phút / Lý do : {user['reason']}" 
                            for i, user in enumerate(muted_users_list, start=1))
    else:
        result = "➜ Xin Chúc Mừng !\n➜ Nhóm Không Có Thành Viên Nào Tiêu Cực !\n➜ Hãy Tiếp Tục Phát Huy Nhé !"
    return result

def print_blocked_users_in_group(bot, thread_id):
    settings = read_settings()
    blocked_users_group = settings.get("block_user_group", {})

    if thread_id not in blocked_users_group:
        return "➜ Nhóm Này Không Có Ai Bị Block !"

    blocked_users = blocked_users_group[thread_id].get('blocked_users', [])
    blocked_users_list = []

    for author_id in blocked_users:
        user_name = get_user_name_by_id(bot, author_id)  
        blocked_users_list.append({
            "author_id": author_id,
            "name": user_name
        })

    blocked_users_list.sort(key=lambda x: x['name'])

    if blocked_users_list:
        result = "➜ Danh Sách Các Thành Viên Bị Block Khỏi Nhóm :\n"
        result += "\n".join(f"{i}. Tên : {user['name']} - ID : {user['author_id']}" for i, user in enumerate(blocked_users_list, start=1))
    else:
        result = "➜ Nhóm Không Có Ai Bị Block Khỏi Nhóm !"
    return result

def add_users_to_ban_list(bot, author_ids, thread_id, reason):
    settings = read_settings()

    current_time = int(time.time())
    muted_users = settings.get("muted_users", [])
    violations = settings.get("violations", {})
    duration_minutes = settings.get("rules", {}).get("word", {}).get("duration", 30)
    response=""
    
    for author_id in author_ids:
        user = bot.fetchUserInfo(author_id).changed_profiles[author_id].displayName

        if not any(entry["author_id"] == author_id and entry["thread_id"] == thread_id for entry in muted_users):
            muted_users.append({
                "author_id": author_id,
                "thread_id": thread_id,
                "reason": reason,
                "muted_until": current_time + 60 * duration_minutes
            })

        if author_id not in violations:
            violations[author_id] = {}

        if thread_id not in violations[author_id]:
            violations[author_id][thread_id] = {
                "profanity_count": 0,
                "spam_count": 0,
                "penalty_level": 0
            }

        violations[author_id][thread_id]["profanity_count"] += 1  
        violations[author_id][thread_id]["penalty_level"] += 1 
        
        response += f"➜ {user} Đã Bị Cấm Nhắn Tin Trong {duration_minutes} Phút !\n"
    
    settings['muted_users'] = muted_users
    settings['violations'] = violations
    write_settings(settings)
    return response

def remove_users_from_ban_list(bot, author_ids, thread_id):
    settings = read_settings()
    muted_users = settings.get("muted_users", [])
    violations = settings.get("violations", {})
    response = f""
    
    for author_id in author_ids:
        user = bot.fetchUserInfo(author_id).changed_profiles[author_id].displayName  
        initial_count = len(muted_users)
        muted_users = [entry for entry in muted_users if not (entry["author_id"] == author_id and entry["thread_id"] == thread_id)]
        removed = False
        
        if author_id in violations:
            if thread_id in violations[author_id]:
                del violations[author_id][thread_id]

                if not violations[author_id]:
                    del violations[author_id]
                removed = True
 
        if (initial_count != len(muted_users)) or removed:
            response += f"➜ Chúc Mừng Thành Viên {user} Đã Được Phép Nhắn Tin !\n"
        else:
            response += f"➜ {user} Không Có Trong Danh Sách Cấm Nhắn Tin !\n"
       
    settings['muted_users'] = muted_users
    settings['violations'] = violations
    write_settings(settings)
    return response

def block_users_from_group(bot, author_ids, thread_id):
    response = ''
    block_user = [] 
  
    settings = read_settings()
 
    if "block_user_group" not in settings:
        settings["block_user_group"] = {}

    if thread_id not in settings["block_user_group"]:
        settings["block_user_group"][thread_id] = {'blocked_users': []}

    for author_id in author_ids:    
        user = bot.fetchUserInfo(author_id).changed_profiles[author_id].displayName
    
        bot.blockUsersInGroup(author_id, thread_id)  
        block_user.append(user) 

        if author_id not in settings["block_user_group"][thread_id]['blocked_users']:
            settings["block_user_group"][thread_id]['blocked_users'].append(author_id) 
    write_settings(settings)

    if block_user:
        blocked_users_str = ', '.join(block_user)  
        response = f"➜ {blocked_users_str} Đã Bị Chặn Khỏi Nhóm !"
    else:
        response = f"➜ Không Ai Bị Chặn Khỏi Nhóm !"    
    return response

def unblock_users_from_group(bot, author_ids, thread_id):
    response = ''
    unblocked_users = [] 

    settings = read_settings()

    if "block_user_group" in settings and thread_id in settings["block_user_group"]:
        blocked_users = settings["block_user_group"][thread_id]['blocked_users']
        
        for author_id in author_ids:     
            user = bot.fetchUserInfo(author_id).changed_profiles[author_id].displayName
     
            if author_id in blocked_users:
                bot.unblockUsersInGroup(author_id, thread_id) 
                unblocked_users.append(user)  
                blocked_users.remove(author_id)  
      
        if not blocked_users:
            del settings["block_user_group"][thread_id]      
        write_settings(settings)

    if unblocked_users:
        unblocked_users_str = ', '.join(unblocked_users)  
        response = f"➜ {unblocked_users_str} Đã Được Bỏ Chặn Khỏi Nhóm !"
    else:
        response = f"➜ Không Có Thành Viên Nào Bị Chặn Trong Nhóm !"  
    return response

def kick_users_from_group(bot, uids, thread_id):
    response = f""
    for uid in uids:
        try:        
            bot.kickUsersInGroup(uid, thread_id)
            bot.blockUsersInGroup( uid, thread_id)
     
            user_name = get_user_name_by_id(bot, uid)
         
            response += f"➜ Đã Kick Thành Viên {user_name} Khỏi Nhóm Thành Công !\n"
        except Exception as e:           
            user_name = get_user_name_by_id(bot, uid)
            response += f"➜ Không Thể Kick Thành Viên {user_name} Khỏi Nhóm !\n" 
    return response

def extract_uids_from_mentions(message_object):
    uids = []
    if message_object.mentions:      
        uids = [mention['uid'] for mention in message_object.mentions if 'uid' in mention]
    return uids

def add_admin(bot, author_id, mentioned_uids, settings):
    admin_bot = settings.get("admin_bot", [])
    response = f""
    for uid in mentioned_uids:
        if author_id not in admin_bot:
            response = f"➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot"
        elif uid not in admin_bot:
            admin_bot.append(uid)
            response += f"➜ Đã Duyệt Người Dùng : {get_user_name_by_id(bot, uid)} Vào Danh Sách Admin Của Bot !\n"
        else:
            response += f"➜ Người Dùng {get_user_name_by_id(bot, uid)} Đã Có Trong Danh Sách Admin Của Bot !\n"

    settings['admin_bot'] = admin_bot
    write_settings(settings)
    return response

def remove_admin(bot, author_id, mentioned_uids, settings):
    admin_bot = settings.get("admin_bot", [])
    response = f""
    for uid in mentioned_uids:
        if author_id not in admin_bot:
            response = f"➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot"
        elif uid in admin_bot:
            admin_bot.remove(uid)
            response += f"➜ Đã Xóa Người Dùng {get_user_name_by_id(bot, uid)} Khỏi Danh Sách Admin Của Bot !\n"
        else:
            response += f"➜ Người Dùng {get_user_name_by_id(bot, uid)} Không Có Trong Danh Sách Admin Của Bot !\n"

    settings['admin_bot'] = admin_bot
    write_settings(settings)
    return response

def handle_bot_command(message, message_object, thread_id, thread_type, author_id, bot):
    def send_bot_response():
        try:
            parts = message_object.content.split()
            if len(parts) == 1:
                response = (
                    "🎉 Chào Mừng Bạn Đến Với Bot 🤖️\n"
                    f"   ➜ {PREFIX}Bot Info : ♨️ Xem Thông Tin Chi Tiết Về Bot 🤖\n"
                    f"   ➜ {PREFIX}Bot On/Off : 🚀 Bật/ 🛑 Tắt Bot Trong Nhóm (OA)\n"
                    f"   ➜ {PREFIX}Bot Admin Add/Remove/List : 👑 Thêm/Xóa/Xem Danh Sách Admin Của Bot 🤖\n"
                    f"   ➜ {PREFIX}Bot NoiQuy : 💢 Xem Nội Quy Của Nhóm (OA)\n"
                    f"   ➜ {PREFIX}Bot Ban/Unban/List : 🚫 Danh Sách/ 😷 Khóa / 😘 Mở Chat Người Dùng\n"
                    f"   ➜ {PREFIX}Bot Kick : 💪Xóa Người Dùng Khỏi Nhóm (OA)\n"
                    f"   ➜ {PREFIX}Bot Block/Unblock/List : 💪Chặn Người Dùng Khỏi Nhóm (OA)\n"
                    f"   ➜ {PREFIX}Bot Setup On/Off : ⚙️ Bật/Tắt Nội Quy Nhóm (OA)\n"
                    f"   ➜ {PREFIX}Bot Link On/Off : 🔗 Bật Tắt Gửi Link Nhóm (OA)\n"
                    f"   ➜ {PREFIX}Bot Rule Word [a] [b] : 📖  Quy Định Cấm a Lần Vi Phạm, Phạt m Phút Cho Nhóm (OA)\n"
                    f"   ➜ {PREFIX}Bot Word Add/Remove [Từ Cấm] : ✍️ Thêm/Xóa Từ Cấm Cho Nhóm (OA)\n"
                    f"🤖 Bot Sẵn Sàng Phục Vụ Bạn 🌸"
                )
            else:
                action = parts[1].lower()
                if action == 'on':
                    if not is_admin(author_id):
                        response = f"➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot"
                    elif thread_type != ThreadType.GROUP:
                        response = f"➜ Lệnh Này Chỉ Khả Thi Ở Trong Nhóm !"
                    else:
                        response = bot_on_group(bot, thread_id)
                elif action == 'off':
                    if not is_admin(author_id):
                        response = f"➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot"
                    elif thread_type != ThreadType.GROUP:
                        response = f"➜ Lệnh Này Chỉ Khả Thi Ở Trong Nhóm !"
                    else:
                        response = bot_off_group(bot, thread_id)
                elif action == 'info':
                    response = (
                        "➜ 💻 Phiên Bản : Mới Nhất\n"
                        "➜ 📅 Ngày Cập Nhật : Mới Nhất\n"
                        "➜ 👨‍💻 Tác Giả : 𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜\n"
                        f"➜ 📖 Cách Dùng : Nhập Lệnh [{PREFIX}Bot Hoặc {PREFIX}Menu]\n"
                        "➜ ⏰ Thời Gian Chờ : 1 -> 10 Giây\n"
                        "➜ 🎧 Tổng Lệnh : /Bot (13), /Menu (36)"
                    )
                elif action == 'admin':
                    if len(parts) < 3:
                        response = f"➜ Vui Lòng Nhập [List/Add/Remove] Sau Lệnh : {PREFIX}Bot Admin\n➜ Ví Dụ : {PREFIX}Bot Admin List Hoặc {PREFIX}Bot Admin Add @𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜 Hoặc {PREFIX}Bot Admin Remove @𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜 !"
                    else:
                        settings = read_settings()
                        admin_bot = settings.get("admin_bot", [])  
                        sub_action = parts[2].lower()
                        if sub_action == 'add':
                            if len(parts) < 4:
                                response = f"➜ Vui Lòng @Tag Tên Người Dùng Sau Lệnh : {PREFIX}Bot Admin Add\n➜ Ví Dụ : {PREFIX}Bot Admin Add @𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜 !"
                            else:
                                if author_id not in admin_bot:
                                    response = f"➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot"
                                else:
                                    mentioned_uids = extract_uids_from_mentions(message_object)
                                    response = add_admin(bot, author_id, mentioned_uids, settings)
                        elif sub_action == 'remove':
                            if len(parts) < 4:
                                response = f"➜ Vui Lòng @Tag Tên Người Dùng Sau Lệnh : {PREFIX}Bot Admin Remove\n➜ Ví Dụ : {PREFIX}Bot Admin Remove @𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜 !"
                            else:
                                if author_id not in admin_bot:
                                    response = f"➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot"
                                else:
                                    mentioned_uids = extract_uids_from_mentions(message_object)
                                    response = remove_admin(bot, author_id, mentioned_uids, settings)
                        elif sub_action == 'list':
                            if admin_bot:
                                response = f"Danh Sách Các Admin Của Bot 𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜\n"
                                for idx, uid in enumerate(admin_bot, start=1):
                                    response += f"➜ Tên : {get_user_name_by_id(bot, uid)} - ID : {author_id}\n"
                            else:
                                response = f"➜ Không Có Admin Của Bot Nào Trong Danh Sách !"
                        else:
                            response = f"➜ Lệnh [/Bot Admin {sub_action}] Không Được Hỗ Trợ !"

                elif action == 'setup':
                    if len(parts) < 3:
                        response = f"➜ Vui Lòng Nhập [On/Off] Sau Lệnh : {PREFIX}Bot Setup\n➜ Ví Dụ : {PREFIX}Bot Setup On Hoặc {PREFIX}Bot Setup Off !"
                    else:
                        setup_action = parts[2].lower()
                        if setup_action == 'on':
                            if not is_admin(author_id):
                                response = f"➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot"
                            elif thread_type != ThreadType.GROUP:
                                response = f"➜ Lệnh Này Chỉ Khả Thi Ở Trong Nhóm !"
                            else:
                                response = setup_bot_on(bot, thread_id)
                        elif setup_action == 'off':
                            if not is_admin(author_id):
                                response = f"➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot"
                            elif thread_type != ThreadType.GROUP:
                                response = f"➜ Lệnh Này Chỉ Khả Thi Ở Trong Nhóm !"
                            else:
                                response = setup_bot_off(bot,thread_id)
                        else:
                            response = f"➜ Lệnh [{PREFIX}Bot Setup {setup_action}] Không Được Hỗ Trợ !"
                elif action == 'link':
                    if len(parts) < 3:
                        response = f"➜ Vui Lòng Nhập [On/Off] Sau Lệnh : {PREFIX}Bot Link\n➜ Ví Dụ : {PREFIX}Bot Link On Hoặc {PREFIX}Bot Link Off"
                    else:
                        link_action = parts[2].lower()
                        if not is_admin(author_id):
                            response = f"➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot"
                        elif thread_type != ThreadType.GROUP:
                            response = f"➜ Lệnh Này Chỉ Khả Thi Ở Trong Nhóm !"
                        else:
                            settings = read_settings()

                            if 'allow_link' not in settings:
                                settings['allow_link'] = {}
                      
                            if link_action == 'on':
                                settings['allow_link'][thread_id] = True
                                response = f"➜ Tùy Chọn Cho Phép Gửi Link Đã Được Bật Cho Nhóm Này !"
                            elif link_action == 'off':
                                settings['allow_link'][thread_id] = False
                                response = f"➜ Tùy Chọn Cho Phép Gửi Link Đã Được Tắt Cho Nhóm Này !"
                            else:
                                response = f"➜ Lệnh [{PREFIX}Bot Link {link_action}] Không Được Hỗ Trợ !"
                        write_settings(settings)
                elif action == 'word':
                    if len(parts) < 4:
                        response = f"➜ Vui Lòng Nhập [Add/Remove] [Từ Khóa] Sau Lệnh : {PREFIX}Bot Word\n➜ Ví Dụ : {PREFIX}Bot Word Add [Từ Khóa] Hoặc {PREFIX}Bot Word Remove [Từ Khóa] !"
                    else:
                        if not is_admin(author_id):
                            response = f"➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot"
                        elif thread_type != ThreadType.GROUP:
                            response = f"➜ Lệnh Này Chỉ Khả Thi Ở Trong Nhóm !"
                        else:
                            word_action = parts[2].lower()
                            word = ' '.join(parts[3:])
                            if word_action == 'add':
                                response = add_forbidden_word(word)
                            elif word_action == 'remove':
                                response = remove_forbidden_word(word)
                            else:
                                response = f"➜ Lệnh [{PREFIX}Bot Word {word_action}] Không Được Hỗ Trợ\n➜ Ví Dụ Hướng Dẫn : {PREFIX}Bot Word Add [Từ Khóa] Hoặc {PREFIX}Bot Word Remove [Từ Khóa] !"
                elif action == 'noiquy':
                    settings = read_settings()
                    rules=settings.get("rules", {})
                    word_rule = rules.get("word", {"threshold": 3, "duration": 30})
                    threshold_word = word_rule["threshold"]
                    duration_word = word_rule["duration"]
                    group_admins = settings.get('group_admins', {})
                    admins = group_admins.get(thread_id, [])
                    group = bot.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                    if admins:
                        response = (
                            f"➜ 📘 Nội Quy Của Bot 𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜 Được Áp Dụng Cho Nhóm : {group.name} - ID : {thread_id} 🏘\n"
                            f"➜ 1. Không Sử Dụng Từ Ngữ Thô Tục Trong Nhóm 🏘\n"
                            f"➜ 2. Nếu Vi Phạm {threshold_word} Lần Sẽ Bị Cấm Nhắn Tin {duration_word} Phút ⏰\n"
                            f"➜ 3. Nếu Tái Phạm 2 Lần Sẽ Bị Xóa Khỏi Nhóm 🏘"
                        )
                    else:
                        response = (
                            f"➜ Nội Quy Không Áp Dụng Cho Nhóm : {group.name} - ID : {thread_id}\n➜ Lý Do : Bot 𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜 Chưa Được Setup Hoặc Bot Không Có Key Quản Trị Nhóm !"
                        )
                elif action == 'ban':               
                    if len(parts) < 3:
                        response = f"➜ Vui Lòng Nhập List Hoặc Ban @Tag Tên Sau Lệnh : {PREFIX}Bot\n➜ Ví Dụ : {PREFIX}Bot List Hoặc {PREFIX}Bot Ban @𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜 !"
                    else:
                        s_action = parts[2]                         
                        if s_action == 'list':
                            response = print_muted_users_in_group(bot, thread_id)
                        else:
                            
                            if not is_admin(author_id):
                                response = f"➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot"
                            elif thread_type != ThreadType.GROUP:
                                response = f"➜ Lệnh Này Chỉ Khả Thi Ở Trong Nhóm !"
                            elif check_admin_group(bot,thread_id)==False:
                                response = f"➜ Lệnh Này Không Khả Thi Do Bot Không Có Key Quản Trị Nhóm !"
                            else:                               
                                uids = extract_uids_from_mentions(message_object)
                                response = add_users_to_ban_list(bot, uids, thread_id,"Admin Của Bot Cấm")
                elif action == 'unban':
                    if len(parts) < 3:
                        response = f"➜ Vui Lòng Nhập @Tag Tên Sau Lệnh : {PREFIX}Bot Unban\n➜ Ví Dụ : {PREFIX}Bot Unban @𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜 !"
                    else:
                        if not is_admin(author_id):
                            response = f"➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot"
                        elif thread_type != ThreadType.GROUP:
                            response = f"➜ Lệnh Này Chỉ Khả Thi Ở Trong Nhóm !"
                        else:                          
                            uids = extract_uids_from_mentions(message_object)
                            response = remove_users_from_ban_list(bot, uids, thread_id)
                elif action == 'unblock':
                    if len(parts) < 3:
                        response = f"➜ Vui Lòng Nhập UID Sau Lệnh : {PREFIX}Bot Unblock\n➜ Ví Dụ : {PREFIX}Bot Unblock 552955919389827360,..."
                    else:
                        if not is_admin(author_id):
                            response = f"➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot"
                        elif thread_type != ThreadType.GROUP:
                            response = f"➜ Lệnh Này Chỉ Khả Thi Ở Trong Nhóm !"
                        else:                          
                            ids_str = parts[2]  
                            print(f"➜ Chuỗi UID : {ids_str}")
                            
                            uids = [uid.strip() for uid in ids_str.split(',') if uid.strip()]
                            
                            print(f"➜ Danh Sách UID : {uids}")                        
                            if uids:                             
                                response = unblock_users_from_group(bot, uids, thread_id)
                            else:
                                response = f"➜ Không Có UID Nào Hợp Lệ Để Bỏ Chặn !"
                elif action == 'kick':
                    if len(parts) < 3:
                        response = f"➜ Vui Lòng Nhập @Tag Tên Sau Lệnh : {PREFIX}Bot Kick\n➜ Ví Dụ : {PREFIX}Bot Kick @𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜 !"
                    else:
                        if not is_admin(author_id):
                            response = f"➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot"
                        elif thread_type != ThreadType.GROUP:
                            response = f"➜ Lệnh Này Chỉ Khả Thi Ở Trong Nhóm !"
                        elif check_admin_group(bot,thread_id)==False:
                                response = f"➜ Lệnh Này Không Khả Thi Do Bot Không Có Key Quản Trị Nhóm !"
                                write_settings(settings)
                        else:
                            uids = extract_uids_from_mentions(message_object)
                            response = kick_users_from_group(bot, uids, thread_id)
                elif action == 'rule':
                    if len(parts) < 5:
                        response = f"➜ Vui Lòng Nhập Word [a = Lần] [b = Phút] Sau Lệnh : {PREFIX}Bot Rule\n➜ Ví Dụ : {PREFIX}Bot Rule Word 3 60"
                    else:
                        rule_type = parts[2].lower()
                        try:
                            threshold = int(parts[3])
                            duration = int(parts[4])
                        except ValueError:
                            response = f"➜ Số Lần Và Phút Phạt Phải Là Số Nguyên !"
                        else:
                            settings = read_settings()
                            if rule_type not in "word":
                                response = f"➜ Lệnh [{PREFIX}Bot Rule {rule_type}] Không Được Hỗ Trợ\n➜ Ví Dụ Hướng Dẫn : {PREFIX}Bot Rule Word 3 60"
                            else:
                                if not is_admin(author_id):
                                    response = f"➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot"
                                elif thread_type != ThreadType.GROUP:
                                    response = f"➜ Lệnh Này Chỉ Khả Thi Ở Trong Nhóm !"
                                else:
                                    settings.setdefault("rules", {})
                                    settings["rules"][rule_type] = {
                                        "threshold": threshold,
                                        "duration": duration
                                    }
                                    write_settings(settings)
                                    response = f"➜ Đã Cập Nhật Nội Quy Cho {rule_type} : Nếu Vi Phạm {threshold} Lần Sẽ Bị Phạt {duration} Phút !"
                else:
                    response = f"➜ Lệnh [{PREFIX}Bot {action}] Không Được Hỗ Trợ !"
            
            if response:
                bot.replyMessage(Message(text=f"{response}"), message_object, thread_id=thread_id, thread_type=thread_type)
        
        except Exception as e:
            print(f"➜ Lỗi : {e}")
            bot.replyMessage(Message(text="➜ Đã Xảy Ra Lỗi Gì Đó !"), message_object, thread_id=thread_id, thread_type=thread_type)

    thread = Thread(target=send_bot_response)
    thread.start()
    
def get_tvh_zlbot():
    return {
        'bot': handle_bot_command
    }
