from zlapi.models import Message, ThreadType

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Tạo Card"
}

def handle_card_command(message, message_object, thread_id, thread_type, author_id, client):
    userId = message_object.mentions[0]['uid'] if message_object.mentions else author_id
    
    if not userId:
        client.send(
            Message(text="➜ Không Tìm Thấy Người Dùng."),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return
    
    
    user_info = client.fetchUserInfo(userId).changed_profiles.get(userId)
    
    if not user_info:
        client.send(
            Message(text="➜ Không Thể Lấy Thông Tin Người Dùng !"),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return
    
    avatarUrl = user_info.avatar
    
    if not avatarUrl:
        client.send(
            Message(text="➜ Người Dùng Này Không Có Ảnh Đại Diện !"),
            thread_id=thread_id,
            thread_type=thread_type
        )
        return
    
    client.sendBusinessCard(userId=userId, qrCodeUrl=avatarUrl, thread_id=thread_id, thread_type=thread_type)

def get_tvh_zlbot():
    return {
        'card': handle_card_command
    }
