from zlapi import ZaloAPI
from zlapi.models import *
import time
from concurrent.futures import ThreadPoolExecutor
import threading
from deep_translator import GoogleTranslator

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Dịch"
}

def handle_translate_command(message, message_object, thread_id, thread_type, author_id, client):
    message_text = message_object.get('content', '').strip()
    parts = message_text.split(maxsplit=1)

    if len(parts) < 2:
        client.replyMessage(
            Message(text="➜ Vui Lòng Nhập Văn Bản Cần Dịch Sau Lệnh : /Dich\nVí Dụ : /Dich Hello"),
            message_object, thread_id, thread_type
        )
        return

    target_language = "vietnamese"
    text_to_translate = parts[1]

    try:
        translated = GoogleTranslator(source='auto', target=target_language).translate(text_to_translate)
        response = f"➜ Đã Dịch Từ {text_to_translate} Sang Tiếng Việt Và Có Nghĩa Là : {translated}"
        client.replyMessage(Message(text=response), message_object, thread_id, thread_type)
    except Exception as e:
        client.replyMessage(
            Message(text=f"➜ Lỗi Khi Dịch : {str(e)}"),
            message_object, thread_id, thread_type
        )

def get_tvh_zlbot():
    return {
        'dich': handle_translate_command
    }
