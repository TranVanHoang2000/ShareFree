from zlapi.models import Message, MessageStyle, MultiMsgStyle
from config import ADMIN
import time

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Duyệt Thành Viên"
}

def handle_duyetmem_command(message, message_object, thread_id, thread_type, author_id, client):
    try:
        group_info = client.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
        creator_id = group_info.get('creatorId')
        admin_ids = group_info.get('adminIds', [])

        if admin_ids is None:
            admin_ids = []

        all_admin_ids = set(admin_ids)
        all_admin_ids.add(creator_id)
        all_admin_ids.update(ADMIN)

        if author_id not in all_admin_ids and author_id not in ADMIN:
            client.replyMessage(
                Message(
                    text="➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot !",
                ),
                message_object, thread_id, thread_type, ttl=12000
            )
            client.sendReaction(message_object, "👎", thread_id, thread_type, reactionType=75)
            return

        pending_members = group_info.pendingApprove.get('uids', [])

        command_parts = message.strip().split()

        if len(command_parts) < 2:
            client.replyMessage(
                Message(
                    text="➜ Lệnh Không Hợp Lệ - VD : DuyetTv [All | List]",
                ),
                message_object, thread_id, thread_type, ttl=12000
            )
            client.sendReaction(message_object, "😏", thread_id, thread_type, reactionType=75)
            return

        action = command_parts[1]

        if action == "list":
            if not pending_members:
                client.replyMessage(
                    Message(
                        text="➜ Hiện Tại Không Có Thành Viên Nào Đang Chờ Duyệt.",
                    ),
                    message_object, thread_id, thread_type, ttl=12000
                )
                client.sendReaction(message_object, "😏", thread_id, thread_type, reactionType=75)
            else:
                client.replyMessage(
                    Message(
                        text=f"➜ Số Thành Viên Đang Chờ Duyệt : {len(pending_members)} Thành Viên !️",
                    ),
                    message_object, thread_id, thread_type, ttl=12000
                )
                client.sendReaction(message_object, "🔍", thread_id, thread_type, reactionType=75)
        elif action == "all":
            if not pending_members:
                client.replyMessage(
                    Message(
                        text="➜ Hiện Tại Không Có Thành Viên Nào Đang Chờ Duyệt.",
                    ),
                    message_object, thread_id, thread_type, ttl=12000
                )
                client.sendReaction(message_object, "👎", thread_id, thread_type, reactionType=75)
                return

            for member_id in pending_members:
                if hasattr(client, 'handleGroupPending'):
                    client.handleGroupPending(member_id, thread_id)
                else:
                    break
                    
            client.replyMessage(
                Message(
                    text="➜ Đã Hoàn Tất Duyệt Tất Cả Thành Viên.",
                ),
                message_object, thread_id, thread_type, ttl=12000
            )
            client.sendReaction(message_object, "✔️", thread_id, thread_type, reactionType=75)
        else:
            client.replyMessage(
                Message(
                    text="Lệnh Không Hợp Lệ - Vd : DuyetTv [All | List]",
                ),
                message_object, thread_id, thread_type, ttl=12000
            )
            client.sendReaction(message_object, "👎", thread_id, thread_type, reactionType=75)

    except Exception as e:
        print(f"➜ Lỗi : {e}")
        client.replyMessage(
            Message(
                text=f"➜ Đã Xảy Ra Lỗi Khi Duyệt : {e}",
            ),
            message_object, thread_id, thread_type, ttl=12000
        )
        client.sendReaction(message_object, "⚠️", thread_id, thread_type, reactionType=75)

def get_tvh_zlbot():
    return {
        'duyettv': handle_duyetmem_command
    }