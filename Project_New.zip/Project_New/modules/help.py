import os
from zlapi.models import Message
import importlib
from config import PREFIX

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'infocription': "Xem Thông Tin Chi Tiết Các Lệnh"
}

def get_all_tvh_zlbot_with_info():
    tvh_zlbot_info = {}

    for module_name in os.listdir('modules'):
        if module_name.endswith('.py') and module_name != '__init__.py':
            module_path = f'modules.{module_name[:-3]}'
            module = importlib.import_module(module_path)

            if hasattr(module, 'info'):
                info = getattr(module, 'info')
                version = info.get('version', 'Chưa Có Thông Tin')
                credits = info.get('credits', 'Chưa Có Thông Tin')
                infocription = info.get('infocription', 'Chưa Có Thông Tin')
                tvh_zlbot_info[module_name[:-3]] = (version, credits, infocription)

    return tvh_zlbot_info

def paginate_commands(tvh_zlbot_info, page=1, page_size=5):
    total_pages = (len(tvh_zlbot_info) + page_size - 1) // page_size
    if page < 1 or page > total_pages:
        return None, total_pages

    start = (page - 1) * page_size
    end = start + page_size

    commands_on_page = list(tvh_zlbot_info.items())[start:end]

    return commands_on_page, total_pages

def handle_help_command(message, message_object, thread_id, thread_type, author_id, client):
    command_parts = message.split()
    
    tvh_zlbot_info = get_all_tvh_zlbot_with_info()

    if len(command_parts) > 1:
        requested_command = command_parts[1].lower()
        
        if requested_command in tvh_zlbot_info:
            version, credits, infocription = tvh_zlbot_info[requested_command]
            single_command_help = f"➜ Tên Lệnh : {requested_command}\n➜ Phiên Bản : {version}\n➜ Người Tạo : {credits}\n➜ Mô Tả : {infocription}"
            message_to_send = Message(text=single_command_help)
            client.replyMessage(message_to_send, message_object, thread_id, thread_type)
            return
        elif command_parts[1].isdigit():
            page = int(command_parts[1])
        else:
            message_to_send = Message(text=f"➜ Không Tìm Thấy Lệnh '{requested_command}' Trong Hệ Thống.")
            client.replyMessage(message_to_send, message_object, thread_id, thread_type)
            return
    else:
        page = 1

    commands_on_page, total_pages = paginate_commands(tvh_zlbot_info, page)

    if commands_on_page is None:
        help_message = f"➜ Trang {page} Không Hợp Lệ, Tổng Số Trang Hiện Có : {total_pages}."
    else:
        help_message_lines = [f"➜ Tổng Số Lệnh Hiện Tại Có : {len(tvh_zlbot_info)} Lệnh !\n"]
        for i, (name, (version, credits, infocription)) in enumerate(commands_on_page, (page - 1) * 5 + 1):
            help_message_lines.append(f"{i}:\n➜ Tên Lệnh : {name}\n➜ Phiên Bản : {version}\n➜ Người Tạo : {credits}\n➜ Mô Tả : {infocription}\n")
            help_message_lines.append(f"➜ Để Xem Thông Tin Các Lệnh Khác, Hãy Dùng Lệnh {PREFIX}Help + Số Trang\n➜ Ví Dụ : {PREFIX}Help 2\n➜ Trang Hiện Tại : {page}/{total_pages}")
            help_message = "\n".join(help_message_lines)

    message_to_send = Message(text=help_message)
    client.replyMessage(message_to_send, message_object, thread_id, thread_type)

def get_tvh_zlbot():
    return {
        'help': handle_help_command
    }