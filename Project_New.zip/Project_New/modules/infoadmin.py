import json
import random
from zlapi import ZaloAPI, ZaloAPIException
from zlapi.models import *
import os

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Xem Thông Tin Admin"
}

def random_img():
    folder_path = r'modules/data'
    all_files = os.listdir(folder_path)
    image_files = [file for file in all_files if file.lower().endswith(('.png', '.jpg', '.jpeg', '.gif'))]
    if not image_files:
        return None
    random_image = random.choice(image_files)
    return os.path.join(folder_path, random_image)

def handle_infoad(message, message_object, thread_id, thread_type, author_id, bot):
    img =random_img()
    msg = (
        f"➜ Thông Tin Admin :\n"
        f"• Tên : Trần Văn Hoàng\n"
        f"• Biệt Danh : TVH\n"
        f"• Ngày Sinh : 24/09/2005\n"
        f"• Giới Tính : Nam\n"
        f"• Email : tranvanhoang2492000@gmail.com\n"
        f"➜ Giới Thiệu Về Tôi :\n"
        f"• Xin Chào Mọi Người ! Tôi Là Trần Văn Hoàng, Biệt Danh TVH, Tôi Là Một Người Đam Mê Về Lập Trình Và Cũng Là Tác Giả Của Bot Này, Tôi Yêu Thích Khám Phá Lập Trình Mới Và Tạo Ra Những Thứ Hữu Ích.\n"
        f"• Liên Hệ Zalo : 0974698128\n"
        f"- Nếu Bạn Có Nhu Cầu Mua File Bot Zalo Tôi Đang Dùng Ib Số Điện Thoại Zalo Trên Để Được Hỗ Trợ Mua Nhé !\n"
        f"➜ Bản Quyền Thuộc Trần Văn Hoàng."
    )
    bot.sendLocalImage(img, thread_id=thread_id, thread_type=thread_type, width=1536, height=1024, message=Message(text=msg))

def get_tvh_zlbot():
    return {
        'infoadmin': handle_infoad
    }