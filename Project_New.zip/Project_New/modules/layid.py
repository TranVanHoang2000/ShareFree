from zlapi.models import Message

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Lấy Id Người Được Tag Hoặc Mình"
}

def handle_layid_command(message, message_object, thread_id, thread_type, author_id, client):
    if message_object.mentions:
        tagged_users = ', '.join([mention['uid'] for mention in message_object.mentions])
    else:
        tagged_users = author_id

    if message_object.mentions:
        response_message = f"➜ ID Của Người Được Tag : {tagged_users}"
    else:
        response_message = f"➜ ID Của Bạn : {tagged_users}"

    message_to_send = Message(text=response_message)
    client.replyMessage(message_to_send, message_object, thread_id, thread_type)

def get_tvh_zlbot():
    return {
        'layid': handle_layid_command
    }