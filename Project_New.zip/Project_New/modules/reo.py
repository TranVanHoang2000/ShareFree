from zlapi.models import *
import os
import time
import threading
from zlapi.models import MultiMsgStyle, Mention, MessageStyle
from config import ADMIN

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Réo Tên"
}

is_reo_running = False

def stop_reo(client, message_object, thread_id, thread_type):
    global is_reo_running
    is_reo_running = False
    client.replyMessage(Message(text="➜ Đã Dừng Réo Tên !"), message_object, thread_id, thread_type)

def handle_reo_command(message, message_object, thread_id, thread_type, author_id, client):
    global is_reo_running

    if author_id not in ADMIN:
        client.replyMessage(
            Message(text="➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot !"),
            message_object, thread_id, thread_type
        )
        return

    command_parts = message.split()
    if len(command_parts) < 2:
        client.replyMessage(Message(text="➜ Hãy Dùng : On/Off Sau Lệnh Reo -Ví Dụ : Reo On Hoặc Reo Off !"), message_object, thread_id, thread_type)
        return

    action = command_parts[1].lower()

    if action == "off":
        if not is_reo_running:
            client.replyMessage(
                Message(text="➜ Đã Dừng Réo Tên !"),
                message_object, thread_id, thread_type
            )
        else:
            stop_reo(client, message_object, thread_id, thread_type)
        return

    if action != "on":
        client.replyMessage(Message(text="➜ Hãy Dùng : On/Off Sau Lệnh Reo -Ví Dụ : Reo On Hoặc Reo Off !"), message_object, thread_id, thread_type)
        return

    if message_object.mentions:
        tagged_users = message_object.mentions[0]['uid']
    else:
        client.replyMessage(Message(text="➜ Hãy Tag Người Bạn Muốn Tag Sau Lệnh : Reo On - Ví Dụ : Reo On @Trần Văn Hoàng !"), message_object, thread_id, thread_type)
        return

    try:
        with open("file/file_txt/loichui.txt", "r", encoding="utf-8") as file:
            Ngon = file.readlines()
    except FileNotFoundError:
        client.replyMessage(
            Message(text="➜ Không Tìm Thấy File loichui.txt."),
            message_object,
            thread_id,
            thread_type
        )
        return

    if not Ngon:
        client.replyMessage(
            Message(text="➜ File loichui.txt Không Có Nội Dung Nào Để Gửi."),
            message_object,
            thread_id,
            thread_type
        )
        return

    is_reo_running = True
    def reo_loop():
        while is_reo_running:
            for noidung in Ngon:
                if not is_reo_running:
                    break
                mention = Mention(tagged_users, length=0, offset=0)
                client.send(Message(text=f" {noidung}", mention=mention), thread_id, thread_type)
                time.sleep(0.1)

    reo_thread = threading.Thread(target=reo_loop)
    reo_thread.start()

def get_tvh_zlbot():
    return {
        'reo': handle_reo_command
    }