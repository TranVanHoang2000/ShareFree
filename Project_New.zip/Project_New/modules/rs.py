import sys, os
from config import ADMIN
from zlapi.models import Message, MultiMsgStyle, MessageStyle

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Reset Bot"
}

ADMIN_ID = ADMIN

def is_admin(author_id):
    return author_id == ADMIN_ID

def handle_rs_command(message, message_object, thread_id, thread_type, author_id, client):
    if not is_admin(author_id):
        noquyen = "➜ Lệnh Này Chỉ Khả Thi Với Admin Của Bot !"
        client.replyMessage(Message(text=noquyen), message_object, thread_id, thread_type)
        return
    
    try:
        msg = f"➜ Bot Đang Tiến Hành Reset !\n➜ Vui Lòng Đợi Một Chút Thời Gian !"
        styles = MultiMsgStyle([
            MessageStyle(offset=0, length=2, style="color", color="#a24ffb", auto_format=False),
            MessageStyle(offset=2, length=len(msg) - 2, style="color", color="#ffaf00", auto_format=False),
            MessageStyle(offset=0, length=40, style="color", color="#a24ffb", auto_format=False),
            MessageStyle(offset=45, length=len(msg) - 2, style="color", color="#ffaf00", auto_format=False),
            MessageStyle(offset=0, length=len(msg), style="font", size="13", auto_format=False)
        ])
        client.replyMessage(Message(text=msg, style=styles), message_object, thread_id, thread_type)
        
        python = sys.executable
        os.execl(python, python, *sys.argv)

    except Exception as e:
        error_msg = f"➜ Lỗi Xảy Ra Khi Reset Bot : {str(e)}"
        client.replyMessage(Message(text=error_msg), message_object, thread_id, thread_type)

def get_tvh_zlbot():
    return {
        'rs': handle_rs_command
    }
