from zlapi.models import Message
import json
import urllib.parse
import requests
import os
from PIL import Image

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Quét Qr"
}

luu_anh = "modules/cache"
ten_anh = os.path.join(luu_anh, "qr_img.jpg")
os.makedirs(luu_anh, exist_ok=True)

def handle_scanqr_command(message, message_object, thread_id, thread_type, author_id, client):
    msg_obj = message_object
    if msg_obj.msgType == "chat.photo":
        img_url = urllib.parse.unquote(msg_obj.content.href.replace("\\/", "/"))
        handle_scan_command(img_url, thread_id, thread_type, client)
    elif msg_obj.quote:
        attach = msg_obj.quote.attach
        if attach:
            try:
                attach_data = json.loads(attach)
                image_url = attach_data.get('hdUrl') or attach_data.get('href')
                if image_url:
                    handle_scan_command(image_url, thread_id, thread_type, client)
                else:
                    send_error_message(thread_id, thread_type, client)
            except json.JSONDecodeError as e:
                print(f"➜ Lỗi JSON : {str(e)}")
                send_error_message(thread_id, thread_type, client)
        else:
            send_error_message(thread_id, thread_type, client)
    else:
        send_error_message(thread_id, thread_type, client)

def handle_scan_command(image_url, thread_id, thread_type, client):
    client.sendMessage(Message(text="➜ Đang Quét QR..."), thread_id=thread_id, thread_type=thread_type)
    if download_image(image_url, ten_anh):
        api_url = "https://api.qrserver.com/v1/read-qr-code/"
        try:
            with Image.open(ten_anh).convert("RGB") as im:
                png_path = ten_anh.replace(".jpg", "_converted.png")
                im.save(png_path, format="PNG")

            with open(png_path, "rb") as img_file:
                files = {"file": img_file}
                response = requests.post(api_url, files=files)
            try:
                os.remove(png_path)
            except:
                pass

            data = response.json()
            datascan = "➜ Không Thấy Dữ Liệu Từ Ảnh QR."

            if data and isinstance(data, list) and len(data) > 0:
                symbol = data[0].get("symbol")
                if symbol and isinstance(symbol, list) and len(symbol) > 0:
                    symbol_data = symbol[0]
                    if symbol_data.get("error"):
                        datascan = f"➜ Lỗi QR : {symbol_data.get('error')}"
                    elif symbol_data.get("data"):
                        datascan = f"➜ Dữ Liệu Của QR : {symbol_data['data']}"

            client.sendMessage(Message(text=datascan), thread_id=thread_id, thread_type=thread_type)

        except Exception as e:
            print("➜ Lỗi Khi Xử Lý QR : ", str(e))
            send_error_message(thread_id, thread_type, client, "➜ Lỗi Khi Quét QR.")
        finally:
            try:
                os.remove(ten_anh)
            except:
                pass
    else:
        send_error_message(thread_id, thread_type, client, "➜ Không Thể Tải Ảnh QR.")

def download_image(url, save_path):
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()
        with open(save_path, "wb") as file:
            for chunk in response.iter_content(1024):
                file.write(chunk)
        return True
    except Exception as e:
        print(f"➜ Lỗi Khi Tải Ảnh : {str(e)}")
        return False

def send_error_message(thread_id, thread_type, client, error_message="➜ Bạn Hãy Vui Lòng Reply Ảnh QR Code Cần Quét."):
    client.sendMessage(Message(text=error_message), thread_id=thread_id, thread_type=thread_type)

def get_tvh_zlbot():
    return {
        'scanqr': handle_scanqr_command
    }