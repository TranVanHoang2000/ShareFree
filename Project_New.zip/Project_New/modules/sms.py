from zlapi.models import *
import datetime
import os
import subprocess
import time

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Spam Sms"
}

last_sms_times = {}
admin_ids = ['552955919389827360']

def handle_sms_command(message, message_object, thread_id, thread_type, author_id, client):
    if not hasattr(client, "last_sms_times"):
        client.last_sms_times = {}

    parts = message.split()
    if len(parts) < 2:
        client.replyMessage(Message(text='➜ Vui Lòng Nhập Số Điện Thoại Sau Lệnh.'), message_object, thread_id=thread_id, thread_type=thread_type)
        return

    attack_phone_number = parts[1]
    if not attack_phone_number.isnumeric() or len(attack_phone_number) != 10:
        client.replyMessage(Message(text='➜ Số Điện Thoại Không Hợp Lệ !'), message_object, thread_id=thread_id, thread_type=thread_type)
        return

    if attack_phone_number in ['113', '911', '114', '115', '0974698128']:
        client.replyMessage(Message(text="➜ Số Này Không Thể Spam."), message_object, thread_id=thread_id, thread_type=thread_type)
        return

    current_time = datetime.datetime.now()
    last_sent_time = client.last_sms_times.get(author_id)
    if last_sent_time:
        elapsed_time = (current_time - last_sent_time).total_seconds()
        if elapsed_time < 120:
            client.replyMessage(Message(text="➜ Vui Lòng Chờ 120 Giây Và Thử Lại."), message_object, thread_id=thread_id, thread_type=thread_type)
            return

    client.last_sms_times[author_id] = current_time
    file_path1 = os.path.join(os.getcwd(), "data/datasms.py")
    subprocess.Popen(["python", file_path1, attack_phone_number, "7"])
    
    time_str = current_time.strftime("%d/%m/%Y %H:%M:%S")
    masked_phone_number = f"{attack_phone_number[:3]}***{attack_phone_number[-3:]}"
    msg_content = f"""@Member

  -----------------------
| Bot Spam SMS & Call Siêu Vip |
  -----------------------
  
Số Điện Thoại :
   ├─◇ {masked_phone_number} 
   ├──────────────
 Thời Gian :
   ├─◇ {time_str} 
   ├──────────────
 Thời Gian Chờ :
   ├─◇ 120
   ├──────────────
 Admin :
   ├─◇ Trần Văn Hoàng
   └──────────────
"""
    mention = Mention(author_id, length=len("@Member"), offset=0)
    color_green = MessageStyle(style="color", color="#4caf50", length=300, offset=0, auto_format=False)
    style = MultiMsgStyle([color_green])
    client.replyMessage(Message(text=msg_content.strip(), style=style, mention=mention), message_object, thread_id=thread_id, thread_type=thread_type)

def get_tvh_zlbot():
    return {'sms': handle_sms_command}
