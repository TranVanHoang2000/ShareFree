from zlapi.models import Message, Mention, ThreadType
from config import ADMIN
import time

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Spam Tin Nhắn"
}

stop_spam = False
spam_text = ""

def handle_spam_command(message, message_object, thread_id, thread_type, author_id, client):
    global stop_spam, spam_text
    if author_id not in ADMIN:
        client.replyMessage(
            Message(text="➜ Lệnh Này Chỉ Khả Thi Với 𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜 !"), 
            message_object, thread_id, thread_type
        )
        return
    
    try:
        parts = message.split(" ", 1)
        if len(parts) < 2:
            client.replyMessage(
                Message(text="➜ Vui Lòng Nhập Nội Dung Cần Spam !"), 
                message_object, thread_id, thread_type
            )
            return
            
        content = parts[1].strip()
        words = content.split()

        if words[-1].isdigit():
            spam_count = int(words[-1])
            spam_text = " ".join(words[:-1])
        else:
            spam_count = 10
            spam_text = content

        if spam_count <= 0:
            client.replyMessage(
                Message(text="➜ Số Lần Spam Phải Lớn Hơn 0 !"), 
                message_object, thread_id, thread_type
            )
            return
        
        stop_spam = False
        sent_count = 0

        for _ in range(spam_count):
            if stop_spam:
                break
            client.send(
                Message(text=spam_text),
                thread_id, thread_type, ttl=1000
            )
            sent_count += 1
            time.sleep(0.1)

        client.replyMessage(
            Message(text=f"➜ Đã Spam {sent_count} Lần Với Nội Dung :\n➤ {spam_text}"),
            message_object, thread_id, thread_type
        )
        
    except Exception as e:
        client.replyMessage(
            Message(text=f"➜ Lỗi : {str(e)}"),
            message_object, thread_id, thread_type
        )

def handle_stop_spam_command(message, message_object, thread_id, thread_type, author_id, client):
    global stop_spam, spam_text
    if author_id not in ADMIN:
        client.replyMessage(
            Message(text="➜ Lệnh Này Chỉ Khả Thi Với 𝙏𝙧ầ𝙣 𝙑ă𝙣 𝙃𝙤à𝙣𝙜 !"), 
            message_object, thread_id, thread_type
        )
        return
    
    stop_spam = True
    client.replyMessage(
        Message(text=f"➜ Đã Dừng Spam Với Nội Dung : '{spam_text}'"),
        message_object, thread_id, thread_type
    )

def get_tvh_zlbot():
    return {
        'spam': handle_spam_command,
        'spam-off': handle_stop_spam_command
    }
