import os
import requests
import json
import urllib.parse
from urllib.parse import urlparse, urlunparse
from zlapi.models import Message
from PIL import Image
from io import BytesIO

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Tạo Sticker Từ Ảnh, Video"
}

def handle_sticker_command(message, message_object, thread_id, thread_type, author_id, client):
    if message_object.quote:
        attach = getattr(message_object.quote, 'attach', None)
        if attach:
            try:
                attach_data = json.loads(attach)
            except json.JSONDecodeError:
                client.sendMessage(
                    Message(text="➜ Dữ Liệu Không Hợp Lệ."),
                    thread_id=thread_id,
                    thread_type=thread_type
                )
                return

            media_url = attach_data.get('hdUrl') or attach_data.get('href')
            if not media_url:
                client.sendMessage(
                    Message(text="➜ Không Tìm Thấy URL."),
                    thread_id=thread_id,
                    thread_type=thread_type
                )
                return

            media_url = media_url.replace("\\/", "/")
            media_url = urllib.parse.unquote(media_url)

            if not is_valid_media_url(media_url):
                client.sendMessage(
                    Message(text="➜ URL Không Phải Là Ảnh Hoặc Video Hợp Lệ."),
                    thread_id=thread_id,
                    thread_type=thread_type
                )
                return

            width, height = get_image_dimensions(media_url)
            static_webp_url = replace_extension_to_webp(media_url)
            animation_webp_url = static_webp_url

            send_sticker(client, static_webp_url, animation_webp_url, width, height, thread_id, thread_type)

        else:
            client.sendMessage(
                Message(text="➜ Không Có Tệp Nào Được Reply."),
                thread_id=thread_id,
                thread_type=thread_type
            )
    else:
        client.sendMessage(
            Message(text="➜ Hãy Reply Vào Ảnh Hoặc Video Cần Tạo Sticker."),
            thread_id=thread_id,
            thread_type=thread_type
        )

def is_valid_media_url(url):
    try:
        response = requests.head(url, timeout=5)
        response.raise_for_status()
        content_type = response.headers.get('Content-Type', '')
        return 'video/' in content_type or 'image/' in content_type
    except requests.RequestException:
        return False

def replace_extension_to_webp(url):
    parsed = list(urlparse(url))
    path = parsed[2]
    base, _ = os.path.splitext(path)
    parsed[2] = base + '.webp'
    return urlunparse(parsed)

def get_image_dimensions(url):
    try:
        response = requests.get(url, stream=True, timeout=5)
        response.raise_for_status()
        content_type = response.headers.get('Content-Type', '')
        if 'image' not in content_type:
            return 512, 512
        image = Image.open(BytesIO(response.content))
        return image.width, image.height
    except Exception:
        return 512, 512

def send_sticker(client, staticImgUrl, animationImgUrl, width, height, thread_id, thread_type):
    try:
        client.sendCustomSticker(
            staticImgUrl=staticImgUrl,
            animationImgUrl=animationImgUrl,
            width=width,
            height=height,
            thread_id=thread_id,
            thread_type=thread_type
        )
    except Exception as e:
        client.sendMessage(
            Message(text=f"➜ Không Thể Gửi Sticker : {str(e)}"),
            thread_id=thread_id,
            thread_type=thread_type
        )

def get_tvh_zlbot():
    return {
        'stk': handle_sticker_command
    }
