from zlapi.models import Message
import time
import random
import os
import json
import requests
from PIL import Image, ImageDraw, ImageFont

info = {
    'version': "1.0",
    'credits': "Trần Văn Hoàng",
    'description': "Xem Thời Gian Bot Đã Hoạt Động"
}

start_time = time.time()

def random_color():
    return (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))

def add_text_to_image(uptime_text, additional_text):
    img = Image.open('file/file_anh/anhuptime.jpg')
    draw = ImageDraw.Draw(img)
    
    font_path = "file/file_phongchu/UTM AvoBold_Italic.ttf"
    font_size = 90
    try:
        font = ImageFont.truetype(font_path, font_size)
    except IOError:
        font = ImageFont.load_default()
    
    fill_color = random_color()
    
    additional_bbox = draw.textbbox((0, 0), additional_text, font=font)
    additional_width = additional_bbox[2] - additional_bbox[0]  

    additional_x = (img.width - additional_width) / 2  
    additional_y = 20

    draw.text((additional_x, additional_y), additional_text, fill=fill_color, font=font)

    bbox = draw.textbbox((0, 0), uptime_text, font=font)
    text_width = bbox[2] - bbox[0]  
    text_height = bbox[3] - bbox[1]  

    text_x = (img.width - text_width) / 2  
    text_y = (img.height - text_height) / 2

    draw.text((text_x, text_y), uptime_text, fill=fill_color, font=font)
    
    output_path = 'output_uptime.png'
    img.save(output_path)
    
    return output_path

def send_reactions(client, message_object, thread_id, thread_type):
    for action in "👍":
        try:
            client.sendReaction(message_object, action, thread_id, thread_type, reactionType=75)
        except Exception as e:
            print(f"➜ Lỗi Khi Gửi Phản Ứng {action} : {e}")

def handle_uptime_command(message, message_object, thread_id, thread_type, author_id, client):
    current_time = time.time()
    uptime_seconds = int(current_time - start_time)

    days = uptime_seconds // (24 * 3600)
    uptime_seconds %= (24 * 3600)
    hours = uptime_seconds // 3600
    uptime_seconds %= 3600
    minutes = uptime_seconds // 60
    seconds = uptime_seconds % 60

    uptime_message = f"{days} Ngày, {hours} Giờ, {minutes} Phút, {seconds} Giây"
    additional_text = "Bot By Trần Văn Hoàng"
    
    send_reactions(client, message_object, thread_id, thread_type)

    loading_message = Message(text="➜ Đang Check Thời Gian Bot Đã Hoạt Động...")
    client.sendMessage(loading_message, thread_id, thread_type, ttl=900000)

    try:
        image_path = add_text_to_image(uptime_message, additional_text)
        
        send_reactions(client, message_object, thread_id, thread_type)
        client.sendLocalImage(
            image_path,
            thread_id,
            thread_type,
            width=1920,
            height=1080,
            message=None,
            custom_payload=None,
            ttl=200000
        )
        os.remove(image_path)
        send_reactions(client, message_object, thread_id, thread_type)

        success_message = Message(text="➜ Check Thành Công Thời Gian Bot Đã Hoạt Động !")
        client.sendMessage(success_message, thread_id, thread_type, ttl=60000)

    except requests.exceptions.RequestException as e:
        error_message = Message(text=f"➜ Đã Xảy Ra Lỗi Khi Tạo Ảnh : {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type, ttl=900000)
    except Exception as e:
        error_message = Message(text=f"➜ Đã Xảy Ra Lỗi : {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type, ttl=900000)

def get_tvh_zlbot():
    return {
        'uptime': handle_uptime_command
    }