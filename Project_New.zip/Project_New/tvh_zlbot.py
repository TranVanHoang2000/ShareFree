from zlapi.models import Message
import os
import importlib
from config import *
import modules.bot
import json
import sys
import time
import threading
import re
from zlapi.models import Message
from config import ADMIN, PREFIX
from datetime import datetime
from logging_utils import Logging
from colorama import Fore

RESET = '\033[0m'
BOLD = '\033[1m'
GREEN = '\033[92m'
RED = '\033[91m'

class CommandHandler:
    def __init__(self, client):
        self.client = client
        self.tvh_zlbot = self.load_tvh_zlbot()
        self.auto_tvh_zlbot = self.load_auto_tvh_zlbot()

    def load_tvh_zlbot(self):
        tvh_zlbot = {}
        modules_path = 'modules'
        success_count = 0
        failed_count = 0
        success_tvh_zlbot = []
        failed_tvh_zlbot = []

        for filename in os.listdir(modules_path):
            if filename.endswith('.py') and filename != '__init__.py':
                module_name = filename[:-3]
                try:
                    module = importlib.import_module(f'{modules_path}.{module_name}')
                    if hasattr(module, 'get_tvh_zlbot'):
                        tvh_zlbot.update(module.get_tvh_zlbot())
                        success_count += 1
                        success_tvh_zlbot.append(module_name)
                    else:
                        raise ImportError(f"Module {module_name} Không Có Hàm get_tvh_zlbot !")
                except Exception as e:
                    print(f"\x1b[48;2;243;139;168m ERROR \x1b[0m Không Thể Load Được Module : {module_name} - Lỗi : {e}{RESET}")
                    failed_count += 1
                    failed_tvh_zlbot.append(module_name)

        if success_count > 0:
            print(f"\x1b[48;2;137;180;250m LOADDER PREFIX COMMANDS \x1b[0m Đã Load Thành Công Prefix : {PREFIX}")
            print(f"\x1b[48;2;137;180;250m LOADDER COMMANDS \x1b[0m Đã Load Thành Công {success_count} Lệnh : {', '.join(success_tvh_zlbot)}{RESET}")
        if failed_count > 0:
            print(f"\x1b[48;2;243;139;168m ERROR \x1b[0m Không Thể Load Được {failed_count} Lệnh : {', '.join(failed_tvh_zlbot)}{RESET}")

        return tvh_zlbot

    def load_auto_tvh_zlbot(self):
        auto_tvh_zlbot = {}
        auto_modules_path = 'modules.auto'
        success_count = 0
        failed_count = 0
        success_auto_tvh_zlbot = []
        failed_auto_tvh_zlbot = []

        for filename in os.listdir('modules/auto'):
            if filename.endswith('.py') and filename != '__init__.py':
                module_name = filename[:-3]
                try:
                    module = importlib.import_module(f'{auto_modules_path}.{module_name}')
                    if hasattr(module, 'get_tvh_zlbot'):
                        auto_tvh_zlbot.update(module.get_tvh_zlbot())
                        success_count += 1
                        success_auto_tvh_zlbot.append(module_name)
                    else:
                        raise ImportError(f"Module {module_name} Không Có Hàm get_tvh_zlbot !")
                except Exception as e:
                    print(f"\x1b[48;2;243;139;168m ERROR \x1b[0m Không Thể Load Được Module : {module_name} - Lỗi : {e}{RESET}")
                    failed_count += 1
                    failed_auto_tvh_zlbot.append(module_name)

        if success_count > 0:
            print(f"\x1b[48;2;166;227;161m SUCCESS \x1b[0m Đã Load Thành Công {success_count} Lệnh Auto : {', '.join(success_auto_tvh_zlbot)}{RESET}")
        if failed_count > 0:
            print(f"\x1b[48;2;243;139;168m ERROR \x1b[0m Không Thể Load Được {failed_count} Lệnh Auto : {', '.join(failed_auto_tvh_zlbot)}{RESET}")

        return auto_tvh_zlbot

    def handle_command(self, message, author_id, message_object, thread_id, thread_type):
        auto_command_handler = self.auto_tvh_zlbot.get(message.lower())
        if auto_command_handler:
            auto_command_handler(message, message_object, thread_id, thread_type, author_id, self.client)
            return
        
        if not message.startswith(PREFIX):
            return
        command_name = message[len(PREFIX):].split(' ')[0].lower()
        command_handler = self.tvh_zlbot.get(command_name)

        if command_handler:
            command_handler(message, message_object, thread_id, thread_type, author_id, self.client)
        else:
            self.client.sendMessage(
                f"➜ Không Tìm Thấy Lệnh '{command_name}'\n➜ Hãy Dùng Lệnh {PREFIX}Menu Hoặc {PREFIX}Bot Để Biết Các Lệnh Của Bot !", 
                thread_id, 
                thread_type
            )
