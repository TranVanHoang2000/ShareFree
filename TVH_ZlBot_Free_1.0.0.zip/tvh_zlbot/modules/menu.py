import os
from zlapi.models import Message
import importlib
import time
from datetime import datetime

def get_all_tvh_zlbot():
    tvh_zlbot = {}

    for module_name in os.listdir('modules'):
        if module_name.endswith('.py') and module_name != '__init__.py':
            module_path = f'modules.{module_name[:-3]}'
            module = importlib.import_module(module_path)

            if hasattr(module, 'get_tvh_zlbot'):
                get_tvh_zlbot = module.get_tvh_zlbot()
                tvh_zlbot.update(get_tvh_zlbot)

    command_names = list(tvh_zlbot.keys())
    
    return command_names

def handle_menu_command(message, message_object, thread_id, thread_type, author_id, client):
    # Lấy tất cả các lệnh
    command_names = get_all_tvh_zlbot()

    # Tính tổng số lệnh và tạo danh sách các lệnh
    total_tvh_zlbot = len(command_names)
    numbered_tvh_zlbot = [f"{i+1}. {name}" for i, name in enumerate(command_names)]

    # Tạo nội dung menu
    menu_message = f"Menu By : Trần Văn Hoàng\n-----------------\n𝐌𝐞𝐧𝐮 𝐇𝐢ệ𝐧 Tạ𝐢 Có : {total_tvh_zlbot} 𝐂𝐡ứ𝐜 Nă𝐧𝐠 🌸\nVerison : 𝟏.𝟎.0 /-li \n" + "\n".join(numbered_tvh_zlbot)

    # Gửi ảnh và nội dung menu
    client.sendLocalImage("2.jpg", thread_id=thread_id, thread_type=thread_type, message=Message(text=menu_message), width=736, height=414, ttl=300000)

def get_tvh_zlbot():
    return {
        'menu': handle_menu_command
    }