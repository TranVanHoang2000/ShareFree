# -*- coding: UTF-8 -*-
"""Zalo API for Python

Copyright : (c) 2025 By Trần Văn Hoàng (TVH)
"""
from ._async import ZaloAPI

__all__ = ["ZaloAPI"]
