# -*- coding: UTF-8 -*-
"""Zalo API for Python

Copyright : (c) 2025 By Trần Văn Hoàng (TVH)
"""
from .models import *
from ._client import ZaloAPI

__title__ = "zlapi"
__version__ = "1.0.0"
__description__ = "Zalo API (Website) for Python"

__copyright__ = "Copyright 2025 By Trần Văn Hoàng"

__author__ = " Trần Văn Hoàng x Bot 2025"
__email__ = "Zalo : 0974698128"

__all__ = ["ZaloAPI"]
